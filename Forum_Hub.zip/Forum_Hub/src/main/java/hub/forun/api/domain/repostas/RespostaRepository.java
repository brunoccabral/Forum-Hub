package hub.forun.api.domain.repostas;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RespostaRepository extends JpaRepository<Respostas,Long> {
}

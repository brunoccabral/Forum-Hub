package hub.forun.api.domain.usuario;

public enum Perfis {
    USUARIO,
    ADMIN
}

package hub.forun.api.domain.curso;

public enum Categoria {
    PROGRAMACAO,
    FRONT_END,
    DATA_SCIENCE,
    IA,
    DEVOPS,
    MOBILE,


}

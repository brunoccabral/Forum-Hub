package hub.forun.api.infra.security;

public record DadosTokenJWT(String token) {
}

package hub.forun.api.domain.usuario;

public record DadosAutenticacao(String login,String senha) {
}

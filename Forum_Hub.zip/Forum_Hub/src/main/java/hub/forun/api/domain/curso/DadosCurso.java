package hub.forun.api.domain.curso;

public record DadosCurso(
        String nome,
        Categoria categoria
) {
}

package hub.forun.api.domain.curso;

public class Curso {
}

alter table usuarios
drop column perfil;
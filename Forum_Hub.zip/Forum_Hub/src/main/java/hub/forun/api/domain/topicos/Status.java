package hub.forun.api.domain.topicos;

public enum Status {
    NAO_RESPONDIDO,
    RESPONDIDO
}
